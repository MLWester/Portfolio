using System.ComponentModel.DataAnnotations;

namespace Homework7.Models;

public class Product
{
    public int ProductID { get; set; }

    [Display(Name = "Product Name")]
    public string Name { get; set; } = string.Empty;

    [Display(Name = "Product Description")]
    public string Description { get; set; } = string.Empty;

    [DataType(DataType.Currency)]
    public decimal Price { get; set; }

    
    public List<ProductOrder>? ProductOrders { get; set; } = default!;
}


